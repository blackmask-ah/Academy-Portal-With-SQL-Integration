<?php
$servername = "localhost";
$username = "root";
$password = "as29";
$dbname = "BlackMask";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Fetch latest user_id and corresponding course_id
    $latest = [];

    $userResult = $conn->query("SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1");
    if ($userResult && $row = $userResult->fetch_assoc()) {
        $latest['user_id'] = $row['user_id'];

        $uid = $latest['user_id'];
        $courseResult = $conn->query("SELECT course_id FROM courses WHERE user_id = $uid ORDER BY course_id DESC LIMIT 1");
        if ($courseResult && $crow = $courseResult->fetch_assoc()) {
            $latest['course_id'] = $crow['course_id'];
        } else {
            $latest['course_id'] = "";
        }
    } else {
        $latest['user_id'] = "0";
        $latest['course_id'] = "";
    }

    echo json_encode($latest);
    $conn->close();
    exit();
}

// POST: Handle Payment Form
$payment_id = $conn->real_escape_string($_POST['payment_id']);
$course_id = $conn->real_escape_string($_POST['course_id']);
$payment_method = $conn->real_escape_string($_POST['payment_method']);
$account_type = $conn->real_escape_string($_POST['account_type']);
$user_id = $conn->real_escape_string($_POST['user_id']);

// Validate user_id
$stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "❌ Invalid User ID.";
    exit();
}
$stmt->close();

// Validate course_id
$stmt = $conn->prepare("SELECT course_id FROM courses WHERE course_id = ?");
$stmt->bind_param("s", $course_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "❌ Invalid Course ID.";
    exit();
}
$stmt->close();

// Insert payment
$stmt = $conn->prepare("INSERT INTO payments (payment_id, course_id, payment_method, account_type, user_id) 
                        VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssssi", $payment_id, $course_id, $payment_method, $account_type, $user_id);

if ($stmt->execute()) {
    echo "✅ Payment recorded successfully.";
} else {
    if ($stmt->errno == 1062) {
        echo "❌ This Payment ID is already used.";
    } elseif ($stmt->errno == 1452) {
        echo "❌ Foreign key constraint failed.";
    } else {
        echo "❌ Error: " . $stmt->error;
    }
}

$stmt->close();
$conn->close();
?>
